#################################################################
# FILE : math_print.py
# WRITER : itai kahana, itaygil135 , 316385962
# EXERCISE : intro2cs2 ex1 2020
# DESCRIPTION: A simple program that print pre submit approval message
# STUDENTS I DISCUSSED THE EXERCISE WITH: no one.
# WEB PAGES I USED: nothing.
# NOTES: ...
#################################################################

def secret_function():
    """This function tell as that I know I have to read the pre submit
     response."""
    print('My username is itaygil135 and I know I have to read the '
          'submission response.')

if __name__ == "__main__":
    secret_function()
