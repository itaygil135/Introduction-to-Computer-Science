"""
A palindrome is a word which reads the same backward as forward.
For example: Level, Mom, Noon...
"""


def is_palindrome(word):
    # TODO: implement.
    #  Make sure you ignore case sensitivity. Do not use loops/arrays.
    return


def check_form_palindrome(word1, word2):
    # TODO: implement.
    return


if __name__ == '__main__':
    # We check our implementation by running at least 3 calls with different use cases.
    # Make sure you get only 'True' printed on the screen.
    print(check_form_palindrome("A", "nna") == True)
    print(check_form_palindrome("el", "lev") == True)
    print(check_form_palindrome("ap", "pple") == False)

