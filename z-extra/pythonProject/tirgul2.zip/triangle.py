
def print_triangle_type_by_angles(angle1, angle2, angle3):
    # TODO implement
    return


def print_triangle_type_by_edges(edge1, edge2, edge3):
    # TODO implement
    return


def print_triangle_type():
    # TODO implement
    return


if __name__ == '__main__':
    print_triangle_type()