from typing import Callable
from boggle import CalculatorModel
from gui import CalculatorGUI

class CalculatorController:
    def __init__(self):
        self._gui = CalculatorGUI()
        self._model = CalculatorModel()

        action = self.create_button_action("0")
        for button_text in self._gui.get_button_chars():
            action = self.create_button_action(button_text)
            self._gui.set_button_command(button_text, action)
        self._gui.set_display("0")




        #shuly  create a variable named my_cube_action that holds a fucntion that will be called once the button is pressed
        my_cube_action = self.create_cube_button_action()  # create the variable
        self._gui.set_cube_button_command(my_cube_action)  # connect the variable to the button

        #shuly
        my_clock_action = self.create_clock_button_action()
        self._gui.set_clock_button_command(my_clock_action)


    #shuly  this is the fucntion that actually will be called once the button is pressed
    def my_action(self,text):
        print("here is my text  ", text)
        #self._model.type_in(button_text)
        #self._gui.set_display(self._model.get_display())

    #shuly
    def create_cube_button_action(self):
        def fun(txt):
            #txt = self._gui.get_cube_button_text()
            self.my_action(txt)
            # self._model.type_in(button_text)
            #self._gui.set_display(self._model.get_display())
        return fun

    def create_clock_button_action(self):
        def fun(txt):
            self._model.clock_logic(txt)
        return fun

    def create_button_action(self, button_text):
        def fun():
            self._model.type_in(button_text)
            self._gui.set_display(self._model.get_display())

        return fun

    def run(self):
        self._gui.run()


if __name__ =="__main__":
    CalculatorController().run()
