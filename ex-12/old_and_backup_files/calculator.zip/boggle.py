CLEAR = ""
EQUALS = "="
OP ="+"
DIGIT ="0"

class CalculatorModel:
    _cur_num: str
    _prev_result: float
    _current_display: str
    _op: str
    _last_clicked: str

    def __init__(self):
        self._do_clear()

    def get_display(self):
        return self._current_display

    def type_in(self, c):
        if c.isdigit() or c ==".":
            self._do_digit_clicked(c)
        elif c == "=":
            self._do_equals()
        elif c == "C":
            self._do_clear()
        elif c in {"*", "+" ,"-", "/"}:
            self._do_math_op(c)
        else:
            raise ValueError("unknown key")

    def _do_clear(self):
        self._cur_num = "0"
        self._current_display = "0"
        self._op = "nop"
        self._prev_result = float(0)
        self._last_clicked = CLEAR

    def _do_digit_clicked(self, digit):
        if self._last_clicked is not DIGIT:
            self._cur_num = digit
        else:
            if digit != "." or "." not in self._cur_num:
                self._cur_num += digit
        self._set_display(float("0" + self._cur_num))
        if self._last_clicked == EQUALS:
            self._op = "nop"
        self._last_clicked = DIGIT


    def _do_equals(self):
        func = _get_op_function(self._op)
        try:
            self._prev_result = func(float(self._prev_result), float(self._cur_num))
            self._set_display(self._prev_result)
        except ZeroDivisionError:
            self._prev_result =0
            self._current_display = "Nan"
        self._last_clicked = EQUALS

    def _do_math_op(self,op):
        if self._last_clicked != OP and self._last_clicked != EQUALS:
            self._do_equals()
        self._op = op
        self._last_clicked = OP

    def _set_display(self, num):
        if num.is_integer():
            self._current_display = str(int(num))
        else:
            self._current_display = str(num)

def _get_op_function(action):
    if action == "+":
        return lambda x, y : x+y
    if action == "*":
        return lambda x, y : x*y
    if action == "/":
        return lambda x, y : x/y
    if action == "-":
        return lambda x, y : x-y
    if action == "nop":
        return lambda x, y : y
    else:
        raise ValueError("unknown operator: " + action)
