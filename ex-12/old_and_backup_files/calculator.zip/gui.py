import tkinter
from typing import Callable, Dict, List, Any

BUTTON_HOVER_COLOR = "gray"
REGUALR_COLOR = "lightgray"
BUTTOM_ACTIVE_COLOR = "slateblue"
BUTTON_STYLE = { "font": ("Courier", 30),
                 "borderwidth":1,
                 "relief": tkinter.RAISED,
                 "bg" : REGUALR_COLOR,
                 "activebackground": BUTTOM_ACTIVE_COLOR}



class CalculatorGUI:
    _buttons: Dict[str, tkinter.Button] = {}

    def __init__(self):
        root = tkinter.Tk()
        root.title("my calculator")
        root.resizable(False,False)
        self._main_window = root
        self._outer_frame = tkinter.Frame(root, bg=REGUALR_COLOR,
                                         highlightbackground=REGUALR_COLOR,
                                         highlightthickness=5)
        self._outer_frame.pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=True)
        self._display_label = tkinter.Label(self._outer_frame, font = ("Courier", 30),
                                            bg=REGUALR_COLOR, width=23, relief='ridge')
        self._display_label.pack(side=tkinter.TOP, fill=tkinter.BOTH)
        self._lower_frame = tkinter.Frame(self._outer_frame)
        self._lower_frame.pack(side=tkinter.TOP, fill = tkinter.BOTH, expand=True)
        self._create_bottons_in_lower_frame()
        self._main_window.bind("<Key>", self._key_pressed)

    def run(self):
        self._main_window.mainloop()

    def set_display(self, display_text):
        self._display_label["text"]=display_text

    def set_button_command(self, button_name, cmd: Callable[[], None]):
        self._buttons[button_name].configure(command=cmd)

    def get_button_chars(self):
        return list(self._buttons.keys())

    def _create_bottons_in_lower_frame(self):
        for i in range(4):
            tkinter.Grid.columnconfigure(self._lower_frame, i, weight=1)
        for i in range(5):
            tkinter.Grid.rowconfigure(self._lower_frame, i, weight=1)
        self._make_button("C",0,0)
        self._make_button("/",0,1)
        self._make_button("*",0,2)
        self._make_button("-",0,3)
        self._make_button("7",1,0)
        self._make_button("8",1,1)
        self._make_button("9",1,2)
        self._make_button("+",1,3, rowspan=2)
        self._make_button("4",2,0)
        self._make_button("5",2,1)
        self._make_button("6",2,2)
        self._make_button("1",3,0)
        self._make_button("2",3,1)
        self._make_button("3",3,2)
        self._make_button("=",3,3, rowspan=2)
        self._make_button("0",4,0, columnspan=2)
        self._make_button(".",4,2)

    def _make_button(self, button_char, row, col, rowspan:int=1, columnspan=1):
        button = tkinter.Button(self._lower_frame, text=button_char, **BUTTON_STYLE)
        button.grid(row=row, column=col, rowspan=rowspan, columnspan=columnspan, sticky=tkinter.NSEW)
        self._buttons[button_char] = button

        def _on_enter(event:Any):
            button['background'] = BUTTON_HOVER_COLOR

        def _on_leave(event:Any):
            button['background'] = REGUALR_COLOR

        button.bind("<Enter>", _on_enter)
        button.bind("<Leave>", _on_leave)
        return button

    def _key_pressed(self, event:Any):
        if event.char in self._buttons:
            self._simulate_button_press(event.char)
        elif event.keysym == "Return":
            self._simulate_button_press("=")

    def _simulate_button_press(self, button_char):
        button = self._buttons[button_char]
        button["bg"]= BUTTOM_ACTIVE_COLOR

        def return_button_to_normal():
            x,y = self._main_window.winfo_pointerxy()
            widget_under_mouse = self._main_window.winfo_containing(x,y)
            if widget_under_mouse is button:
                button["bg"] = BUTTON_HOVER_COLOR
            else:
                button["bg"] = REGUALR_COLOR

        button.invoke()
        button.after(100, func=return_button_to_normal())

if __name__ == "__main__":
    cg = CalculatorGUI()
    cg.set_display("TEST MODE")
    cg.run()