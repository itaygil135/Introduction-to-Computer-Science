import tkinter
from functools import partial
from typing import Callable, Dict, List, Any

BUTTON_HOVER_COLOR = "gray"
REGUALR_COLOR = "lightgray"
BUTTOM_ACTIVE_COLOR = "slateblue"
BUTTON_STYLE = { "font": ("Courier", 30),
                 "borderwidth":1,
                 "relief": tkinter.RAISED}
                 #"bg" : REGUALR_COLOR}
                 #"activebackground": BUTTOM_ACTIVE_COLOR}

class GUI:
    _buttons: Dict[str, tkinter.Button] = {}
    _commands: Dict[str, tkinter.Button] = {}
    def __init__(self, board, commands_list):
        self._enable =False
        self._main_window = tkinter.Tk()
        self._main_window.title("boggle")
        self._main_window.resizable(False,False)
        self._outer_frame = tkinter.Frame(self._main_window, bg=REGUALR_COLOR,
                                         highlightbackground="blue",
                                         highlightthickness=5)
        self._outer_frame.pack()

        self._word_label = tkinter.Label(self._outer_frame, font = ("Courier", 30),
                                            bg=REGUALR_COLOR, width=24, relief='ridge')
        self._word_label.pack(side=tkinter.TOP, fill=tkinter.BOTH)

        #create internal frame that will contain the score
        self._score_frame = tkinter.Frame(self._outer_frame,bg="lightblue",highlightbackground ="lightblue",highlightthickness=1)
        self._score_frame.pack(side=tkinter.TOP, fill = tkinter.BOTH, expand=True)

        # define the score label
        self._score_label = tkinter.Label(self._score_frame, font=("Courier", 30),
                                           bg=REGUALR_COLOR, width=12, relief='ridge',
                                           text="score:")
        # 'load' the button to the screen (in the outer_frame)
        self._score_label.pack(side=tkinter.LEFT, fill=tkinter.BOTH)

        self._score_label_value = tkinter.Label(self._score_frame, font=("Courier", 30),
                                           bg=REGUALR_COLOR, width=12, relief='ridge',
                                           text="0" )
        # 'load' the button to the screen (in the outer_frame)
        self._score_label_value.pack(side=tkinter.RIGHT, fill=tkinter.BOTH)

        #create internal frame that will contain the time
        self._time_frame = tkinter.Frame(self._outer_frame,bg="black",highlightbackground ="black",highlightthickness=1)
        self._time_frame.pack(side=tkinter.TOP, fill = tkinter.BOTH, expand=True)
        #define the clock lable
        self._clock_label = tkinter.Label(self._time_frame, font=("Courier", 30),
                                            bg=REGUALR_COLOR, width=12, relief='ridge',
                                            text="time:")
        # 'load' the button to the screen (in the outer_frame)
        self._clock_label.pack(side=tkinter.LEFT, fill=tkinter.BOTH)
        self._clock_label_value = tkinter.Label(self._time_frame, font=("Courier", 30),
                                            bg=REGUALR_COLOR, width=12, relief='ridge',
                                            text="")
        # 'load' the button to the screen (in the outer_frame)
        self._clock_label_value.pack(side=tkinter.RIGHT, fill=tkinter.BOTH)

        #create internal frame that will contain the board
        self._board_frame = tkinter.Frame(self._outer_frame,bg="red",highlightbackground ="red",
                                          highlightthickness=5, height = 240)
        self._board_frame.pack(side=tkinter.TOP, fill = tkinter.BOTH, expand=True)

        #create the board buttons
        self._create_bottons_in_board_frame(board)

        #create internal frame that will contain the board
        self._commands_frame = tkinter.Frame(self._outer_frame,bg="yellow",highlightbackground ="yellow",highlightthickness=5)
        self._commands_frame.pack(side=tkinter.TOP, fill = tkinter.BOTH, expand=True)

        #create the board buttons
        self._create_bottons_in_command_frame(commands_list)

        play_again_label = tkinter.Label(self._outer_frame, text="to play again press the 'again' button", **BUTTON_STYLE,
                                bg=REGUALR_COLOR, fg="black",
                                activebackground=REGUALR_COLOR,activeforeground=BUTTOM_ACTIVE_COLOR)
        play_again_label.pack()


    def set_state(self,state):
        self._enable = state
        for button in self._buttons.values():
            if (state == True):
                button.config(state=tkinter.NORMAL)
                button.config(fg="black")
                button.config(activebackground= BUTTOM_ACTIVE_COLOR)
            else:
                button.config(bg=REGUALR_COLOR ,fg=REGUALR_COLOR)
                button.config(activebackground= REGUALR_COLOR)
                button.config(activeforeground= REGUALR_COLOR)
        pass

    def run(self):
        self._main_window.mainloop()

    def relaod_board(self,board):
        for row in range(len(board)):
            for col in range(len(board[0])):
                self._buttons[(row,col)].configure(text=board[row][col])

    def set_display(self, display_text, score, time):
        self._word_label["text"]=display_text
        self._clock_label_value["text"] = str(time)
        self._score_label_value["text"] = str(score)

    def set_button_command(self, coordinate, action):
        self._buttons[coordinate].configure(command=action)

    def set_commands_command(self, command_text, action):
        self._commands[command_text].configure(command=action)

    def get_button_coordinates(self):
        return list(self._buttons.keys())

    def get_commands_text(self):
        return list(self._commands.keys())


    def _create_bottons_in_board_frame(self, board):
        #create the grid
        for i in range(len(board)):
            tkinter.Grid.columnconfigure(self._board_frame, i, weight=1)
        for i in range(len(board[0])):
            tkinter.Grid.rowconfigure(self._board_frame, i, weight=1)

        # First create 16 buttons for the board cubes, so the coordinate at
        # the board and at the grid will be the same
        for row in range(len(board)):
            for col in range(len(board[0])):
                self._make_button(board[row][col], row, col)

    def _make_button(self, button_text, row, col, rowspan:int=1, columnspan=1):
        button = tkinter.Button(self._board_frame, text=button_text, **BUTTON_STYLE,
                                bg=REGUALR_COLOR, fg=REGUALR_COLOR,
                                activebackground=REGUALR_COLOR,activeforeground=REGUALR_COLOR)

        #button.config(state=tkinter.DISABLED)

        button.grid(row=row, column=col, rowspan=rowspan, columnspan=columnspan, sticky=tkinter.NSEW)
        #create/update dictionary when the coordinate is the key, and the button is the value
        self._buttons[(row,col)] = button

        def _on_enter(event:Any):
            if self._enable == True:
                button['background'] = BUTTON_HOVER_COLOR
            else:
                button['background'] = REGUALR_COLOR

        def _on_leave(event:Any):
            button['background'] = REGUALR_COLOR

        button.bind("<Enter>", _on_enter)
        button.bind("<Leave>", _on_leave)


    def _create_bottons_in_command_frame(self,command_list):
        for command_text in command_list:
            button = tkinter.Button(self._commands_frame, text=command_text, width=8, **BUTTON_STYLE)
            button.pack(side=tkinter.LEFT)
            self._commands[command_text] = button


        # create the game commands
        #self._make_button("Clear",4,0)
        #self._make_button("Start",4,1)
        #self._make_button("Send",4,2)

if __name__ == "__main__":
    cg = GUI()
    cg.set_display("TEST MODE")
    cg.run()


'''
   #shuly  - when this function is called, it returns the string it display
    def get_cube_button_text(self):
        return self._cube_button["text"]

    #shuly - used to connect a function, so  when the button is clicked, this function is called
    def set_cube_button_command(self, cmd: Callable[[], None]):
        arg1=self.get_cube_button_text() # first get the text that is displayed on the button
        self._cube_button.configure(command=partial(cmd,arg1))  # then call the cmd and send the text as a parameter

    # shuly  - when this function is called, it returns the string it display
    def get_clock_button_text(self):
        return self._cube_button["text"]

    # shuly - used to connect a function, so  when the button is clicked, this function is called
    def set_clock_button_command(self, cmd: Callable[[], None]):
        arg1 = self.get_clock_button_text()  # first get the text that is displayed on the button
        self._clock_button.configure(command=partial(cmd, arg1))  # then call the cmd and send the text as a parameter



 def _key_pressed(self, event:Any):
        if event.char in self._buttons:
            self._simulate_button_press(event.char)
        elif event.keysym == "Return":
            self._simulate_button_press("=")

    def _simulate_button_press(self, button_char):
        button = self._buttons[button_char]
        button["bg"]= BUTTOM_ACTIVE_COLOR

        def return_button_to_normal():
            x,y = self._main_window.winfo_pointerxy()
            widget_under_mouse = self._main_window.winfo_containing(x,y)
            if widget_under_mouse is button:
                button["bg"] = BUTTON_HOVER_COLOR
            else:
                button["bg"] = REGUALR_COLOR

        button.invoke()
        button.after(100, func=return_button_to_normal())
'''