import boggle_board_randomizer

class Model:
    def __init__(self):
        self._score = 8
        self._time = 180
        self._enable = False
        self._board = boggle_board_randomizer.randomize_board()
        self._do_clear()
        self._commands_list=["clear","start","send","again"]

    def clock_logic(self, text):
        print("in clock logic  text = ", text)

    def get_display(self):
        return self._current_display

    def get_state(self):
        return self._enable

    def type_in(self, coordinate):
        if coordinate in self._commands_list:
            self._do_command(coordinate)
        else:
            c = self._board[coordinate[0]][coordinate[1]]
            self._do_alpha_clicked(c, coordinate)


    def _do_command(self, coordinate):
        if coordinate == "clear":
            self._do_clear()
            return
        elif coordinate == "start":
            self._enable=True
            return
        elif coordinate == "send":
            self._do_clear()
            return
        elif coordinate == "again":
            self._do_again()
            return
    def _do_clear(self):
        self._path=[]
        self._current_display = ""


    def _do_again(self):
        self._board = boggle_board_randomizer.randomize_board()
        self._enable = False


    def _do_alpha_clicked(self,c ,coordinate):
        if self._enable:
            self._current_display += c
            self._path.append(coordinate)















    '''
    def _set_display(self, word):
        self._current_display = word



    def _do_equals(self):
        func = _get_op_function(self._op)
        try:
            self._prev_result = func(float(self._prev_result), float(self._cur_num))
            self._set_display(self._prev_result)
        except ZeroDivisionError:
            self._prev_result =0
            self._current_display = "Nan"
        self._last_clicked = EQUALS

def _get_op_function(action):
    if action == "+":
        return lambda x, y : x+y
    if action == "*":
        return lambda x, y : x*y
    if action == "/":
        return lambda x, y : x/y
    if action == "-":
        return lambda x, y : x-y
    if action == "nop":
        return lambda x, y : y
    else:
        raise ValueError("unknown operator: " + action)



    def _do_digit_clicked(self, digit):
        if self._last_clicked is not DIGIT:
            self._cur_num = digit
        else:
            if digit != "." or "." not in self._cur_num:
                self._cur_num += digit
        self._set_display(float("0" + self._cur_num))
        if self._last_clicked == EQUALS:
            self._op = "nop"
        self._last_clicked = DIGIT
'''