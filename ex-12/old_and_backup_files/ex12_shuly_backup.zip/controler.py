from typing import Callable
from boggle import Model
from gui import GUI



class CalculatorController:
    def __init__(self):
        self._model = Model()
        self._gui = GUI(self._model._board, self._model._commands_list)

        for coordinate in self._gui.get_button_coordinates():
            action = self.create_button_action(coordinate)
            self._gui.set_button_command(coordinate, action)

        for command_text in self._gui.get_commands_text():
            action = self.create_button_action(command_text)
            self._gui.set_commands_command(command_text, action)
        self._gui.set_display("",99,67)

    def create_button_action(self, coordinate):
        def fun():
            self._model.type_in(coordinate)
            self._gui.set_display(self._model.get_display(),
                                  self._model._score,
                                  self._model._time)

            self._gui.set_state(self._model.get_state())
            self._gui.relaod_board(self._model._board)
        return fun

    def run(self):
        self._gui.run()


if __name__ =="__main__":
    CalculatorController().run()

'''




        #  create a variable named my_cube_action that holds a fucntion that will be called once the button is pressed
        #my_cube_action = self.create_cube_button_action()  # create the variable
        #self._gui.set_cube_button_command(my_cube_action)  # connect the variable to the button

        #
        #my_clock_action = self.create_clock_button_action()
        #self._gui.set_clock_button_command(my_clock_action)


    #  this is the fucntion that actually will be called once the button is pressed
    def my_action(self,text):
        print("here is my text  ", text)
        #self._model.type_in(button_text)
        #self._gui.set_display(self._model.get_display())

    #
    def create_cube_button_action(self):
        def fun(txt):
            #txt = self._gui.get_cube_button_text()
            self.my_action(txt)
            # self._model.type_in(button_text)
            #self._gui.set_display(self._model.get_display())
        return fun
        
        
        

    def create_clock_button_action(self):
        def fun(txt):
            self._model.clock_logic(txt)
        return fun
'''